﻿using System;
using SFML.Graphics;
using SFML.System;
using SFML.Window;

class Program
{
    static RenderWindow Window;

    static Sprite stickSprite;
    static Sprite[] blocks;

    static Ball ball;

    public static void SetStartPosition(int level)
    {
        int index;
        if (level == 1)
        {
            index = 0;
            for (int y = 0; y < 10; y++)
            {
                for (int x = 0; x < 10; x++)
                {
                    blocks[index].Position = new Vector2f(x * (blocks[index].TextureRect.Width + 15) + 75,
                                                                                         y * (blocks[index].TextureRect.Height + 15) + 50);
                    index++;
                }
            }
        }
        if (level == 2)
        {
            index = 0;
            for (int y = 0; y < 10; y++)
            {
                for (int x = 0; x < 10; x++)
                {
                    blocks[index].Position = new Vector2f(x * (blocks[index].TextureRect.Width + 60) + 60,
                                                                                         y * (blocks[index].TextureRect.Height + 15) + 50);
                    index++;
                }
            }
        }
        stickSprite.Position = new Vector2f(400, 500);
        ball.sprite.Position = new Vector2f(375, 400); 
    }

    static void Main(string[] args)
    {
        Window = new RenderWindow(new VideoMode(800, 600), "game");
        Window.Closed += Window_Closed;
        Window.SetFramerateLimit(60);

        ball = new Ball();
        stickSprite = new Sprite(new Texture("Stick.png"));
        blocks = new Sprite[100];
        for (int i = 0; i < blocks.Length; i++) blocks[i] = new Sprite(new Texture("Block.png"));

        SetStartPosition(1);

        while (Window.IsOpen)
        {
            Window.Clear();

            Window.DispatchEvents();
            if (Keyboard.IsKeyPressed(Keyboard.Key.Space)) ball.Start(5, new Vector2f(0, -1));
            if (ball.blocksDestroyed == 100)
            {
                ball.blocksDestroyed = 0;
                SetStartPosition(2);
            }
            ball.Move(new Vector2i(0, 0), new Vector2i(800, 600));
            ball.CheckCollision(stickSprite, "stick");
            for (int i = 0; i < blocks.Length; i++)
            {
                if (ball.CheckCollision(blocks[i], "block") == true)
                {
                    blocks[i].Position = new Vector2f(1000, 1000);
                    break;
                }
            }
            stickSprite.Position = new Vector2f(Mouse.GetPosition(Window).X - stickSprite.Texture.Size.X * 0.5f, stickSprite.Position.Y);

            Window.Draw(ball.sprite);
            Window.Draw(stickSprite);
            for (int i = 0; i < blocks.Length; i++) Window.Draw(blocks[i]);
            Window.Display();
        }
        Console.ReadLine();
    }

    private static void Window_Closed(object sender, EventArgs e)
    {
        Window.Close();
    }
}
